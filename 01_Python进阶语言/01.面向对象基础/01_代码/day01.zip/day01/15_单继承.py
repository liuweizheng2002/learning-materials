"""
案例: 演示单继承, 即: 1个子类继承自 1个父类.

故事1: 一个摊煎饼的老师傅，在煎饼果子界摸爬滚打多年，研发了一套精湛的摊煎饼技术， 师父要把这套技术传授给他的唯一的最得意的徒弟。

分析:
    1. 定义师傅类, Master
        属性: kongfu
        行为: make_cake()
    2. 定义子类, Prentice, 继承师傅类.
"""

# 1. 定义师傅类.
class Master:
    # 1.1 定义属性.
    def __init__(self):
        self.kongfu = '[古法配方]'

    # 1.2 定义行为.
    def make_cake(self):
        print(f'采用 {self.kongfu} 摊煎饼果子.')


# 2.定义徒弟类, 继承自师傅类.
class Prentice(Master):
    pass

# 3.测试.
p = Prentice()
p.make_cake()